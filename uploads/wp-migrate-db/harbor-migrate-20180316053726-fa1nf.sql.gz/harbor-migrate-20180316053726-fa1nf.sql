# WordPress MySQL database migration
#
# Generated: Friday 16. March 2018 05:37 UTC
# Hostname: localhost
# Database: `harbor`
# URL: //d-harbor.test
# Path: /srv/www/harbor/public_html
# Tables: wp_commentmeta, wp_comments, wp_links, wp_masterslider_options, wp_masterslider_sliders, wp_options, wp_postmeta, wp_posts, wp_simply_static_pages, wp_strong_views, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wpsdb_alter_statements, wp_yoast_seo_links, wp_yoast_seo_meta
# Table Prefix: wp_
# Post Types: revision, attachment, nav_menu_item, oembed_cache, page, post, project, vc_grid_item, wpm-testimonial
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------

